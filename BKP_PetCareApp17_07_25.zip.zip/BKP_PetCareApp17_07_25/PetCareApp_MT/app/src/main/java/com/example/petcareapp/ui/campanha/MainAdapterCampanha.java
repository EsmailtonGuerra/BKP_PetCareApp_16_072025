package com.example.petcareapp.ui.campanha;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;

import java.util.ArrayList;

public class MainAdapterCampanha extends RecyclerView.Adapter<MainAdapterCampanha.ViewHolder> {

    private ArrayList<MainModelCampanha> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelCampanha model);
    }

    // Construtor com listener
    public MainAdapterCampanha(Context context, ArrayList<MainModelCampanha> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_campanha, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelCampanha item = mainModels.get(position);
        /*this.listaIdCampanha = listaIdCampanha;
        this.listaTituloCampanha = listaTituloCampanha;
        this.listaInicioCampanha = listaInicioCampanha;
        this.listaEstadoCampanha = listaEstadoCampanha;*/

        holder.listaIdCampanha.setText(item.getListaIdCampanha());
        holder.listaTituloCampanha.setText(item.getListaTituloCampanha());
        holder.listaInicioCampanha.setText(item.getListaInicioCampanha());
        holder.listaEstadoCampanha.setText(item.getListaEstadoCampanha());

        holder.listaTituloCampanha.setMaxLines(1);
        holder.listaTituloCampanha.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterCampanha", "Listener is null!");
            }
        });

        // Limitar o texto do nome vacina para 15 caracteres
        String nomeVacina = mainModels.get(position).getListaTituloCampanha();
        int maxLength = 30;  // Limite de caracteres
        if (nomeVacina.length() > maxLength) {
            nomeVacina = nomeVacina.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaTituloCampanha.setText(nomeVacina);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView listaIdCampanha, listaTituloCampanha, listaInicioCampanha, listaEstadoCampanha;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdCampanha = itemView.findViewById(R.id.listaIdCampanha);
            listaTituloCampanha = itemView.findViewById(R.id.listaTituloCampanha);
            listaInicioCampanha = itemView.findViewById(R.id.listaInicioCampanha);
            listaEstadoCampanha = itemView.findViewById(R.id.listaEstadoCampanha);
        }
    }
}
