package com.example.petcareapp.ui.admGerenciarClinica;

import android.graphics.Bitmap;

public class MainModelGerenciarClinica {
    Integer listaIdGerenciarClinica;
    Bitmap listaFotoGerenciarClinica;
    String listaEmailGerenciarClinica;
    String listaNomeGerenciarClinica;

    public MainModelGerenciarClinica(Integer listaIdGerenciarClinica, Bitmap listaFotoGerenciarClinica, String listaEmailGerenciarClinica, String listaNomeGerenciarClinica) {
        this.listaIdGerenciarClinica = listaIdGerenciarClinica;
        this.listaFotoGerenciarClinica = listaFotoGerenciarClinica;
        this.listaEmailGerenciarClinica = listaEmailGerenciarClinica;
        this.listaNomeGerenciarClinica = listaNomeGerenciarClinica;
    }

    public Integer getListaIdGerenciarClinica() {
        return listaIdGerenciarClinica;
    }
    public Bitmap getListaFotoGerenciarClinica() {
        return listaFotoGerenciarClinica;
    }
    public String getListaEmailGerenciarClinica() {
        return listaEmailGerenciarClinica;
    }
    public String getListaNomeGerenciarClinica() {
        return listaNomeGerenciarClinica;
    }

}

