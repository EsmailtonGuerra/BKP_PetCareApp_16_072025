package com.example.petcareapp.ui.admFeedback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;
import com.example.petcareapp.ui.cartaoVacina.MainAdapterCartaoVacina;
import com.example.petcareapp.ui.cartaoVacina.MainAdapterVacina;
import com.example.petcareapp.ui.cartaoVacina.MainModelCartaoVacina;
import com.example.petcareapp.ui.cartaoVacina.MainModelVacina;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admFeedbackFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admFeedbackFragment extends Fragment {

    String emailUsuarioAtual;
    Integer idUsuarioAtual, idFeedbackClicado;

    RecyclerView listaFeedback;
    TextView tvEmailFeedback, tvMsgFeedback, tvDataFeedback;
    EditText emailFeedback, msgFeedback, etPesquisarFeedback;
    CircleImageView imgFeedback;
    ImageButton btVoltarLista;

    // Recylerview Lista Feedback
    ArrayList<String> listaIdFeedback = new ArrayList<>();
    ArrayList<Bitmap> listaFotoFeedback = new ArrayList<>();
    ArrayList<String> listaEmailFeedback = new ArrayList<>();
    ArrayList<String> listaMsgFeedback = new ArrayList<>();
    ArrayList<String> listaDataFeedback = new ArrayList<>();

    ArrayList<MainModelFeedback> mainModels = new ArrayList<>();
    MainAdapterFeedback mainAdapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admFeedbackFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admFeedbackFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admFeedbackFragment newInstance(String param1, String param2) {
        admFeedbackFragment fragment = new admFeedbackFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_feedback, container, false);

        etPesquisarFeedback = view.findViewById(R.id.etPesquisarFeedback);
        listaFeedback = view.findViewById(R.id.listaFeedback);
        tvEmailFeedback = view.findViewById(R.id.tvEmailFeedback);
        tvMsgFeedback = view.findViewById(R.id.tvMsgFeedback);
        tvDataFeedback = view.findViewById(R.id.tvDataFeedback);
        emailFeedback = view.findViewById(R.id.emailFeedback);
        msgFeedback = view.findViewById(R.id.msgFeedback);
        imgFeedback = view.findViewById(R.id.imgFeedback);
        btVoltarLista = view.findViewById(R.id.btVoltarLista);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaFeedback.setLayoutManager(layoutManager);
        listaFeedback.setItemAnimator(new DefaultItemAnimator());

        mainAdapter = new MainAdapterFeedback(getActivity(), mainModels, new MainAdapterFeedback.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelFeedback model) {
                idFeedbackClicado = Integer.valueOf(model.getListaIdFeedback());
                Bitmap roundedBitmap = null;

                try {
                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM adm_info_feedback WHERE id_feedback = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idFeedbackClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        byte[] fotoBytesTutor = rs.getBytes("foto_tutor");
                        byte[] fotoBytesClinica = rs.getBytes("foto_clinica");

                        if (fotoBytesTutor != null) {
                            // Converter a foto para Bitmap
                            Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytesTutor, 0, fotoBytesTutor.length);
                            roundedBitmap = getRoundedBitmap(fotoBitmap);
                        } else if (!(fotoBytesClinica == null)) {
                            // Converter a foto para Bitmap
                            Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytesClinica, 0, fotoBytesClinica.length);
                            roundedBitmap = getRoundedBitmap(fotoBitmap);
                        } else {
                            Bitmap fotoPadrao = BitmapFactory.decodeResource(getResources(), R.drawable.user);
                            roundedBitmap = getRoundedBitmap(fotoPadrao);
                        }

                        imgFeedback.setImageBitmap(roundedBitmap);
                        emailFeedback.setText(rs.getString("email"));
                        msgFeedback.setText(rs.getString("feedback_mensagem"));

                        Timestamp timestamp = rs.getTimestamp("dt_hr_feedback");
                        if (timestamp != null) {
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR"));
                            String dataFormatada = sdf.format(timestamp);
                            tvDataFeedback.setText(dataFormatada);
                        } else {
                            tvDataFeedback.setText("Data não disponível");
                        }

                    }

                    rs.close();
                    stmt.close();
                    con.close();

                    funMostrarFeedback();

                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes do feedback", e);
                }
            }
        });

        listaFeedback.setAdapter(mainAdapter);

        btVoltarLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                funMostrarLayout();
            }
        });

        etPesquisarFeedback.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()) {
                    updateRecyclerView(); // Mostra toda a lista se não houver texto
                } else {
                    funPesquisarFeedback(s.toString()); // Faz o filtro
                }
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funMostrarLayout();
        funListaFeeback();

    }

    public void funListaFeeback() {
        Bitmap roundedBitmap = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_feedback ORDER BY id_feedback DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdFeedback.clear();
            listaFotoFeedback.clear();
            listaEmailFeedback.clear();
            listaMsgFeedback.clear();
            listaDataFeedback.clear();;

            // Preparar o formatador de data
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR"));

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_feedback");

                byte[] fotoBytesTutor = rs.getBytes("foto_tutor");
                byte[] fotoBytesClinica = rs.getBytes("foto_clinica");

                if (fotoBytesTutor != null) {
                    // Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytesTutor, 0, fotoBytesTutor.length);
                    roundedBitmap = getRoundedBitmap(fotoBitmap);
                } else if (!(fotoBytesClinica == null)) {
                    // Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytesClinica, 0, fotoBytesClinica.length);
                    roundedBitmap = getRoundedBitmap(fotoBitmap);
                } else {
                    Bitmap fotoPadrao = BitmapFactory.decodeResource(getResources(), R.drawable.user);
                    roundedBitmap = getRoundedBitmap(fotoPadrao);
                }

                String email = rs.getString("email");
                String msg = rs.getString("feedback_mensagem");

                // Obter e formatar a data
                Timestamp timestamp = rs.getTimestamp("dt_hr_feedback");
                String dataFormatada = (timestamp != null) ? sdf.format(timestamp) : "Data não disponível";

                // Adicionar os dados nas listas
                listaIdFeedback.add(id);
                listaFotoFeedback.add(roundedBitmap);
                listaEmailFeedback.add(email);
                listaMsgFeedback.add(msg);
                listaDataFeedback.add(dataFormatada);

            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            Log.e("ERRO", "Erro ao buscar feedback", e);
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdFeedback.size(); i++) {
            MainModelFeedback model = new MainModelFeedback(listaFotoFeedback.get(i), listaIdFeedback.get(i), listaEmailFeedback.get(i), listaMsgFeedback.get(i), listaDataFeedback.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    public void funPesquisarFeedback(String termo) {
        ArrayList<MainModelFeedback> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        for (int i = 0; i < listaIdFeedback.size(); i++) {
            String nome = listaEmailFeedback.get(i).toLowerCase();
            String email = listaMsgFeedback.get(i).toLowerCase();
            String data = listaDataFeedback.get(i).toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro) || data.contains(filtro)) {
                listaFiltrada.add(new MainModelFeedback(
                        listaFotoFeedback.get(i),
                        listaIdFeedback.get(i),
                        listaEmailFeedback.get(i),
                        listaMsgFeedback.get(i),
                        listaDataFeedback.get(i)
                ));
            }
        }

        mainAdapter.atualizarLista(listaFiltrada);
    }

    public void funMostrarLayout() {
        imgFeedback.setVisibility(GONE);
        btVoltarLista.setVisibility(GONE);
        tvEmailFeedback.setVisibility(GONE);
        emailFeedback.setVisibility(GONE);
        tvMsgFeedback.setVisibility(GONE);
        msgFeedback.setVisibility(GONE);
        tvDataFeedback.setVisibility(GONE);
        etPesquisarFeedback.setVisibility(VISIBLE);
        listaFeedback.setVisibility(VISIBLE);
        etPesquisarFeedback.setText(null);
    }

    public void funMostrarFeedback() {
        etPesquisarFeedback.setVisibility(GONE);
        listaFeedback.setVisibility(GONE);
        imgFeedback.setVisibility(VISIBLE);
        btVoltarLista.setVisibility(VISIBLE);
        tvEmailFeedback.setVisibility(VISIBLE);
        emailFeedback.setVisibility(VISIBLE);
        tvMsgFeedback.setVisibility(VISIBLE);
        msgFeedback.setVisibility(VISIBLE);
        tvDataFeedback.setVisibility(VISIBLE);
        emailFeedback.setEnabled(false);
        msgFeedback.setEnabled(false);
        etPesquisarFeedback.setText(null);
    }

}