package com.example.petcareapp.ui.cartaoVacina;

import android.graphics.Bitmap;

public class MainModelLista {
    Integer listaIdPetVac1;
    Integer listaIdCartaoVac1;
    Bitmap listaFotoPetVac1;
    String listaNomePetVac1;
    String listaNomeVacinaVac1;
    String listaDtVacinaVac1;


    public MainModelLista(Integer listaIdPetVac1, Integer listaIdCartaoVac1, Bitmap listaFotoPetVac1, String listaNomePetVac1, String listaNomeVacinaVac1, String listaDtVacinaVac1) {
        this.listaIdPetVac1 = listaIdPetVac1;
        this.listaIdCartaoVac1 = listaIdCartaoVac1;
        this.listaFotoPetVac1 = listaFotoPetVac1;
        this.listaNomePetVac1 = listaNomePetVac1;
        this.listaNomeVacinaVac1 = listaNomeVacinaVac1;
        this.listaDtVacinaVac1 = listaDtVacinaVac1;
    }

    public Integer getListaIdPetVac1() {
        return listaIdPetVac1;
    }
    public Integer getListaIdCartaoVac1() {
        return listaIdCartaoVac1;
    }
    public Bitmap getListaFotoPetVac1() {
        return listaFotoPetVac1;
    }
    public String getListaNomePetVac1() {
        return listaNomePetVac1;
    }
    public String getListaNomeVacinaVac1() {
        return listaNomeVacinaVac1;
    }
    public String getListaDtVacinaVac1() {
        return listaDtVacinaVac1;
    }

}
