package com.example.petcareapp.ui.admGerenciarAdm;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterGerenciarAdm extends RecyclerView.Adapter<MainAdapterGerenciarAdm.ViewHolder> {

    private ArrayList<MainModelGerenciarAdm> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelGerenciarAdm model);
    }

    // Construtor com listener
    public MainAdapterGerenciarAdm(Context context, ArrayList<MainModelGerenciarAdm> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapterGerenciarAdm(FragmentActivity activity, ArrayList<MainModelGerenciarAdm> mainModels) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_gerenciar, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelGerenciarAdm item = mainModels.get(position);

        holder.listaIdGerenciarAdm.setText(String.valueOf(item.getListaIdGerenciarAdm()));

        Bitmap foto = item.getListaFotoGerenciarAdm();
        if (foto != null) {
            holder.listaFotoGerenciarAdm.setImageBitmap(foto);
        } else {
            // Usa imagem padrão do drawable
            holder.listaFotoGerenciarAdm.setImageResource(R.drawable.user);
        }

        holder.listaEmailGerenciarAdm.setText(item.getListaEmailGerenciarAdm());
        holder.listaNomeGerenciarAdm.setText(item.getListaNomeGerenciarAdm());

        holder.listaEmailGerenciarAdm.setMaxLines(1);
        holder.listaEmailGerenciarAdm.setEllipsize(TextUtils.TruncateAt.END);

        holder.listaNomeGerenciarAdm.setMaxLines(1);
        holder.listaNomeGerenciarAdm.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterLista", "Listener is null!");
            }
        });

        // Limitar o texto do email para 25 caracteres
        String emailAdm = mainModels.get(position).getListaEmailGerenciarAdm();
        int maxLength = 25;  // Limite de caracteres
        if (emailAdm.length() > maxLength) {
            emailAdm = emailAdm.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaEmailGerenciarAdm.setText(emailAdm);

        // Limitar o texto do nome para 25 caracteres
        String nomeAdm = mainModels.get(position).getListaNomeGerenciarAdm();
        int maxLength1 = 25;  // Limite de caracteres
        if (nomeAdm.length() > maxLength1) {
            nomeAdm = nomeAdm.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomeGerenciarAdm.setText(nomeAdm);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView listaFotoGerenciarAdm;
        TextView listaIdGerenciarAdm, listaEmailGerenciarAdm, listaNomeGerenciarAdm;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdGerenciarAdm = itemView.findViewById(R.id.listaIdGerenciar);
            listaFotoGerenciarAdm = itemView.findViewById(R.id.listaFotoGerenciar);
            listaEmailGerenciarAdm = itemView.findViewById(R.id.listaEmailGerenciar);
            listaNomeGerenciarAdm = itemView.findViewById(R.id.listaNomeGerenciar);
        }
    }

    public void atualizarLista(ArrayList<MainModelGerenciarAdm> novaLista) {
        mainModels.clear();
        mainModels.addAll(novaLista);
        notifyDataSetChanged();
    }

}


