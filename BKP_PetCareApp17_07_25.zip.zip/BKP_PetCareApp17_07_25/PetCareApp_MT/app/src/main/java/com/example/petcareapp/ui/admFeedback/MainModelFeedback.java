package com.example.petcareapp.ui.admFeedback;

import android.graphics.Bitmap;

public class MainModelFeedback {
    Bitmap listaFotoFeedback;
    String listaIdFeedback;
    String listaEmailFeedback;
    String listaMsgFeedback;
    String listaDataFeedback;

    public MainModelFeedback(Bitmap listaFotoFeedback, String listaIdFeedback, String listaEmailFeedback, String listaMsgFeedback, String listaDataFeedback) {
        this.listaFotoFeedback = listaFotoFeedback;
        this.listaIdFeedback = listaIdFeedback;
        this.listaEmailFeedback = listaEmailFeedback;
        this.listaMsgFeedback = listaMsgFeedback;
        this.listaDataFeedback = listaDataFeedback;
    }

    public Bitmap getListaFotoFeedback() {
        return listaFotoFeedback;
    }

    public String getListaIdFeedback() {
        return listaIdFeedback;
    }

    public String getListaEmailFeedback() {
        return listaEmailFeedback;
    }

    public String getListaMsgFeedback() {
        return listaMsgFeedback;
    }

    public String getListaDataFeedback() {
        return listaDataFeedback;
    }

}
