package com.example.petcareapp.ui.doenca;

import static android.view.View.GONE;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.Doenca;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DoencasFragment extends Fragment {

    private String emailUsuarioAtual,tipoUserAtual;
    private Integer idUsuarioAtual;
    private RecyclerView recyclerView;
    private DoencaAdapter adapter;
    private List<Doenca> listaDoencas = new ArrayList<>();
    private AutoCompleteTextView editEspecie, editDoenca;
    private EditText editPesquisar, editNome, editRaca, editDetalhes;
    private ProgressBar progressBar;
    private Button btnPesquisar, btnAdicionar, btnExcluir, btnLimpar;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private List<String> especies = new ArrayList<>();
    private List<String> doencas = new ArrayList<>();
    private Doenca doencaSelecionada = null;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_doenca, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        editPesquisar = view.findViewById(R.id.editPesquisar);
        editEspecie  = view.findViewById(R.id.editEspecie);
        editDoenca   = view.findViewById(R.id.editDoenca);
        editNome     = view.findViewById(R.id.editNome);
        editRaca     = view.findViewById(R.id.editRaca);
        editDetalhes = view.findViewById(R.id.doencasFragment_detalhes);
        recyclerView = view.findViewById(R.id.recyclerViewDoencas);
        progressBar  = view.findViewById(R.id.progressBar);
        btnPesquisar = view.findViewById(R.id.btnPesquisar);
        btnAdicionar = view.findViewById(R.id.btnAdicionarTabela);
        btnExcluir   = view.findViewById(R.id.btnExcluir);
        btnLimpar    = view.findViewById(R.id.btnLimpar);

        setupRecyclerView();
        setupButtons();
        setupDropdowns();
        carregarEspecies();
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                tipoUserAtual = rs.getString("tipo_user");
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        if (tipoUserAtual.equals("Tutor") || tipoUserAtual.equals("Clinica")) {
            btnAdicionar.setVisibility(GONE);
            btnExcluir.setVisibility(GONE);
        }
    }

    private void setupRecyclerView() {
        adapter = new DoencaAdapter(listaDoencas);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickListener(doenca -> {
            doencaSelecionada = doenca;
            editEspecie.setText(doenca.getEspecie());
            editDoenca.setText(doenca.getNomeDoenca());
            editNome.setText(doenca.getNomeAnimal());
            editRaca.setText(doenca.getRacaAnimal());
            editDetalhes.setText(doenca.getDetalhesDoenca());
            btnExcluir.setEnabled(true);
        });
    }

    private void setupButtons() {
        btnPesquisar.setOnClickListener(v -> pesquisarDoencas());
        btnAdicionar.setOnClickListener(v -> {
            if (validarCampos()) adicionarDoenca();
        });
        btnExcluir.setOnClickListener(v -> {
            if (doencaSelecionada == null) {
                Toast.makeText(getContext(), "Selecione um item primeiro", Toast.LENGTH_SHORT).show();
                return;
            }
            new AlertDialog.Builder(getContext())
                    .setTitle("Confirmar Exclusão")
                    .setMessage("Excluir " + doencaSelecionada.getNomeAnimal() + "?")
                    .setPositiveButton("Sim", (d,w) -> excluirDoenca(doencaSelecionada.getId()))
                    .setNegativeButton("Não", null)
                    .show();
        });
        btnLimpar.setOnClickListener(v -> limparCampos());
    }

    private void setupDropdowns() {
        ArrayAdapter<String> espAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, especies);
        editEspecie.setAdapter(espAdapter);
        editEspecie.setThreshold(1);

        editEspecie.setOnItemClickListener((p, v, pos, id) -> {
            String esp = p.getItemAtPosition(pos).toString();
            carregarDoencasPorEspecie(esp);
            editDoenca.setEnabled(true);
        });

        ArrayAdapter<String> doeAdapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_dropdown_item_1line, doencas);
        editDoenca.setAdapter(doeAdapter);
        editDoenca.setThreshold(1);
    }

    private boolean validarCampos() {
        boolean ok = true;
        if (TextUtils.isEmpty(editEspecie.getText()))  { editEspecie.setError("Informe espécie"); ok = false; }
        if (TextUtils.isEmpty(editNome.getText()))     { editNome.setError("Informe nome"); ok = false; }
        if (TextUtils.isEmpty(editRaca.getText()))     { editRaca.setError("Informe raça"); ok = false; }
        if (TextUtils.isEmpty(editDoenca.getText()))   { editDoenca.setError("Informe doença"); ok = false; }
        if (TextUtils.isEmpty(editDetalhes.getText())) { editDetalhes.setError("Informe detalhes"); ok = false; }
        return ok;
    }

    private void carregarEspecies() {
        showProgress(true);
        executor.execute(() -> {
            try (Connection con = ConexaoMysql.conectar()) {
                especies.clear();
                ResultSet rs = con.prepareStatement("SELECT DISTINCT especie FROM doencas").executeQuery();
                while (rs.next()) especies.add(rs.getString(1));

                requireActivity().runOnUiThread(() -> {
                    ((ArrayAdapter<String>)editEspecie.getAdapter()).notifyDataSetChanged();
                    showProgress(false);
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(), "Erro espécies: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void carregarDoencasPorEspecie(String especie) {
        showProgress(true);
        executor.execute(() -> {
            try (Connection con = ConexaoMysql.conectar()) {

                PreparedStatement st = con.prepareStatement(
                        "SELECT DISTINCT nome_doenca FROM doencas WHERE especie=?");
                st.setString(1, especie);
                ResultSet rs = st.executeQuery();
                while (rs.next()) doencas.add(rs.getString(1));

                requireActivity().runOnUiThread(() -> {
                    ((ArrayAdapter<String>)editDoenca.getAdapter()).notifyDataSetChanged();
                    showProgress(false);
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(), "Erro doenças: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void pesquisarDoencas() {
        showProgress(true);
        executor.execute(() -> {
            try (Connection con = ConexaoMysql.conectar()) {
                String termo = editPesquisar.getText().toString().trim();
                String especie = editEspecie.getText().toString().trim();
                String nomeAnimal = editNome.getText().toString().trim();
                String raca = editRaca.getText().toString().trim();
                String doenca = editDoenca.getText().toString().trim();

                StringBuilder sql = new StringBuilder("SELECT * FROM doencas WHERE 1=1");
                List<String> params = new ArrayList<>();

                if (!TextUtils.isEmpty(termo)) {
                    sql.append(" AND (especie LIKE ? OR nome_animal LIKE ? OR raca_animal LIKE ? OR nome_doenca LIKE ? OR detalhes_doenca LIKE ?)");
                    for (int i = 0; i < 5; i++) {
                        params.add("%" + termo + "%");
                    }
                } else {
                    if (!TextUtils.isEmpty(especie)) {
                        sql.append(" AND especie = ?");
                        params.add(especie);
                    }
                    if (!TextUtils.isEmpty(nomeAnimal)) {
                        sql.append(" AND nome_animal LIKE ?");
                        params.add("%" + nomeAnimal + "%");
                    }
                    if (!TextUtils.isEmpty(raca)) {
                        sql.append(" AND raca_animal LIKE ?");
                        params.add("%" + raca + "%");
                    }
                    if (!TextUtils.isEmpty(doenca)) {
                        sql.append(" AND nome_doenca LIKE ?");
                        params.add("%" + doenca + "%");
                    }
                }

                try (PreparedStatement stmt = con.prepareStatement(sql.toString())) {
                    for (int i = 0; i < params.size(); i++) {
                        stmt.setString(i + 1, params.get(i));
                    }

                    ResultSet rs = stmt.executeQuery();
                    List<Doenca> resultados = new ArrayList<>();
                    while (rs.next()) {
                        resultados.add(new Doenca(
                                rs.getInt("id_doenca"),
                                rs.getString("especie"),
                                rs.getString("nome_animal"),
                                rs.getString("raca_animal"),
                                rs.getString("nome_doenca"),
                                rs.getString("detalhes_doenca")
                        ));
                    }

                    requireActivity().runOnUiThread(() -> {
                        showProgress(false);
                        listaDoencas.clear();
                        listaDoencas.addAll(resultados);
                        adapter.notifyDataSetChanged();
                        recyclerView.scrollToPosition(0);

                        if (resultados.isEmpty()) {
                            Toast.makeText(getContext(), "Nenhum resultado encontrado", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(), "Erro na pesquisa: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void adicionarDoenca() {
        showProgress(true);
        executor.execute(() -> {
            try (Connection con = ConexaoMysql.conectar()) {
                String sql = "INSERT INTO doencas(especie,nome_animal,raca_animal,nome_doenca,detalhes_doenca) VALUES(?,?,?,?,?)";
                PreparedStatement st = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
                st.setString(1, editEspecie.getText().toString().trim());
                st.setString(2, editNome.getText().toString().trim());
                st.setString(3, editRaca.getText().toString().trim());
                st.setString(4, editDoenca.getText().toString().trim());
                st.setString(5, editDetalhes.getText().toString().trim());
                st.executeUpdate();
                ResultSet keys = st.getGeneratedKeys();
                if (keys.next()) {
                    final long id = keys.getLong(1);
                    requireActivity().runOnUiThread(() -> {
                        showProgress(false);
                        Toast.makeText(getContext(), "Adicionado ID:" + id, Toast.LENGTH_SHORT).show();
                        limparCampos();
                        pesquisarDoencas();
                    });
                }
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(), "Erro adicionar: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void excluirDoenca(int id) {
        showProgress(true);
        executor.execute(() -> {
            try (Connection con = ConexaoMysql.conectar()) {
                PreparedStatement st = con.prepareStatement("DELETE FROM doencas WHERE id_doenca=?");
                st.setInt(1, id);
                int rows = st.executeUpdate();
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(),
                            rows>0 ? "Excluído com sucesso" : "Falha ao excluir",
                            Toast.LENGTH_SHORT).show();
                    limparCampos();
                    pesquisarDoencas();
                });
            } catch (Exception e) {
                requireActivity().runOnUiThread(() -> {
                    showProgress(false);
                    Toast.makeText(getContext(), "Erro excluir: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void limparCampos() {
        editPesquisar.setText("");
        editEspecie.setText("");
        editDoenca.setText("");
        editNome.setText("");
        editRaca.setText("");
        editDetalhes.setText("");


    }

    private void showProgress(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : GONE);
        btnPesquisar.setEnabled(!show);
        btnAdicionar.setEnabled(!show);
        btnExcluir.setEnabled(!show && doencaSelecionada != null);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        executor.shutdownNow();
    }
}
